import { ActiveWorkout, Analysis } from '../types';

export function analyzeWorkout(workout: ActiveWorkout): Analysis {
  let totalSets = 0;
  let hardSets = 0; // RPE >= 7
  let failureSets = 0; // RPE >= 9
  let totalVolume = 0;
  let missedData = 0;

  workout.exercises.forEach(ex => {
    ex.sets.forEach(set => {
      if(!set.weight || !set.reps) {
        missedData++;
        return;
      }
      const w = parseFloat(set.weight);
      const r = parseFloat(set.reps);
      const rpe = parseFloat(set.rpe) || 0;

      totalSets++;
      totalVolume += w * r;

      if(rpe >= 7) hardSets++;
      if(rpe >= 9) failureSets++;
    });
  });

  // Calcular Nota
  let score = 0;
  let feedback: string[] = [];
  let grade = "C";

  // 1. Consistência
  if(missedData > 0) feedback.push("❌ Você esqueceu de anotar cargas em alguns exercícios.");
  
  // 2. Intensidade (RPE)
  const intensityRatio = totalSets > 0 ? hardSets / totalSets : 0;
  
  if (intensityRatio >= 0.8) {
    score += 40;
    feedback.push("🔥 Intensidade Excelente! A maioria das séries foi efetiva.");
  } else if (intensityRatio >= 0.5) {
    score += 20;
    feedback.push("⚠️ Intensidade Média. Muitas séries longe da falha (Junk Volume).");
  } else {
    feedback.push("💩 Intensidade Baixa. Você foi treinar ou passear? Aumente a carga.");
  }

  // 3. Volume
  if(totalSets >= 10 && totalSets <= 25) {
    score += 30;
    feedback.push("✅ Volume de treino dentro do ideal por sessão.");
  } else if (totalSets < 10) {
    feedback.push("📉 Volume baixo. Poderia ter feito mais exercícios.");
  } else {
    feedback.push("🛑 Volume excessivo. Cuidado com o overtraining.");
  }

  // 4. Falha
  if (failureSets > 0) {
    score += 30;
    feedback.push("💪 Você atingiu a falha técnica em algumas séries. Ótimo estímulo.");
  }

  // Gerar Conceito
  if (score >= 90) grade = "S (GOD)";
  else if (score >= 70) grade = "A (Bom)";
  else if (score >= 50) grade = "B (Médio)";
  else if (score >= 30) grade = "C (Fraco)";
  else grade = "D (Vergonhoso)";

  return { grade, feedback, totalVolume, totalSets };
}
