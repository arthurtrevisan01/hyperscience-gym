import { WORKOUT_PLANS } from '../data';
import { ArrowLeft, ArrowRight } from 'lucide-react';

interface WorkoutSelectProps {
  planKey: string;
  onBack: () => void;
  onSelectDay: (planKey: string, dayIndex: number) => void;
}

export const WorkoutSelect = ({ planKey, onBack, onSelectDay }: WorkoutSelectProps) => {
  const plan = WORKOUT_PLANS[planKey];

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 pb-20">
      <button onClick={onBack} className="mb-4 text-blue-400 text-sm flex items-center">
        <ArrowLeft className="w-4 h-4 mr-1" /> Voltar
      </button>
      <h2 className="text-2xl font-bold mb-4">{plan.name}</h2>
      <p className="mb-4 text-gray-400">Qual dia você vai treinar hoje?</p>

      {plan.days.map((day, index) => (
        <div 
          key={day.id}
          onClick={() => onSelectDay(planKey, index)} 
          className="bg-[#1f2937] rounded-xl p-4 mb-4 shadow-md active:scale-95 transition cursor-pointer flex justify-between items-center group"
        >
          <div>
            <h3 className="font-bold text-lg">{day.name}</h3>
            <p className="text-xs text-gray-500">{day.exercises.length} Exercícios</p>
          </div>
          <div className="bg-gray-700 group-hover:bg-blue-600 transition rounded-full p-2">
            <ArrowRight className="w-4 h-4 text-white" />
          </div>
        </div>
      ))}
    </div>
  );
};
