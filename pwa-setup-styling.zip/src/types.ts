export interface WorkoutSet {
  weight: string;
  reps: string;
  rpe: string;
}

export interface ActiveExercise {
  name: string;
  category?: string; // Used for swapping
  sets: WorkoutSet[];
}

export interface Analysis {
  grade: string;
  feedback: string[];
  totalVolume: number;
  totalSets: number;
}

export interface ActiveWorkout {
  planName: string;
  dayName: string;
  exercises: ActiveExercise[];
  startTime: number;
  endTime?: number;
  duration?: number;
  analysis?: Analysis;
}

// Data Definition Types
export interface ExerciseDefinition {
  name: string;
  category: string;
}

export interface WorkoutDay {
  id: string;
  name: string;
  exercises: ExerciseDefinition[];
}

export interface WorkoutPlan {
  name: string;
  desc: string;
  days: WorkoutDay[];
}

export interface ExerciseCategory {
  id: string;
  name: string;
  exercises: string[];
}
