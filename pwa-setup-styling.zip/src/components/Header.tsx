export const Header = () => {
  return (
    <header className="fixed top-0 w-full bg-gray-800 p-4 shadow-lg z-50 flex justify-between items-center">
      <h1 className="text-xl font-bold text-blue-400 tracking-tighter">
        HYPER<span className="text-white">SCIENCE</span>
      </h1>
      <div id="status-indicator" className="w-3 h-3 rounded-full bg-green-500"></div>
    </header>
  );
};
