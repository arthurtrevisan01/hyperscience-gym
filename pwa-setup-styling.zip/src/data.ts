import { WorkoutPlan, ExerciseCategory } from './types';

// Categorias de exercícios para substituição inteligente
export const EXERCISE_CATEGORIES: Record<string, ExerciseCategory> = {
  compound_push_h: {
    id: 'compound_push_h',
    name: 'Empurrar Horizontal (Peito)',
    exercises: ['Supino Reto (Barra)', 'Supino Reto (Halter)', 'Supino Reto (Máquina)', 'Flexão de Braço (Peso do Corpo)', 'Supino Inclinado (Barra)', 'Supino Inclinado (Halter)']
  },
  compound_push_v: {
    id: 'compound_push_v',
    name: 'Empurrar Vertical (Ombro)',
    exercises: ['Desenvolvimento Militar (Barra)', 'Desenvolvimento Halter', 'Desenvolvimento Máquina', 'Arnold Press']
  },
  iso_chest: {
    id: 'iso_chest',
    name: 'Isolamento Peito',
    exercises: ['Crucifixo (Halter)', 'Crucifixo (Máquina/Peck Deck)', 'Crossover Polia Alta', 'Crossover Polia Média']
  },
  iso_delt_side: {
    id: 'iso_delt_side',
    name: 'Isolamento Ombro Lateral',
    exercises: ['Elevação Lateral (Halter)', 'Elevação Lateral (Polia)', 'Elevação Lateral (Máquina)']
  },
  compound_pull_v: {
    id: 'compound_pull_v',
    name: 'Puxada Vertical (Costas)',
    exercises: ['Puxada Alta (Polia)', 'Barra Fixa (Pronada)', 'Barra Fixa (Supinada/Chin-up)', 'Graviton']
  },
  compound_pull_h: {
    id: 'compound_pull_h',
    name: 'Puxada Horizontal (Costas)',
    exercises: ['Remada Curvada (Barra)', 'Remada Unilateral (Serrote)', 'Remada Baixa (Triângulo)', 'Remada Máquina Fechada']
  },
  iso_back: {
    id: 'iso_back',
    name: 'Isolamento Costas/Posterior Ombro',
    exercises: ['Face Pull', 'Crucifixo Inverso (Máquina)', 'Crucifixo Inverso (Halter)', 'Pulldown (Polia)']
  },
  legs_compound_quad: {
    id: 'legs_compound_quad',
    name: 'Pernas Composto (Foco Quadríceps)',
    exercises: ['Agachamento Livre', 'Leg Press 45', 'Agachamento Hack', 'Afundo/Passada', 'Agachamento Búlgaro']
  },
  legs_iso_quad: {
    id: 'legs_iso_quad',
    name: 'Isolamento Quadríceps',
    exercises: ['Cadeira Extensora', 'Sissy Squat']
  },
  legs_compound_post: {
    id: 'legs_compound_post',
    name: 'Pernas Composto (Posterior)',
    exercises: ['Levantamento Terra (Convencional)', 'Stiff (Barra/Halter)', 'RDL (Romainan Deadlift)', 'Bom Dia (Good Morning)']
  },
  legs_iso_post: {
    id: 'legs_iso_post',
    name: 'Isolamento Posterior',
    exercises: ['Mesa Flexora', 'Cadeira Flexora', 'Flexão Nórdica']
  },
  arms_bi: {
    id: 'arms_bi',
    name: 'Bíceps',
    exercises: ['Rosca Direta (Barra)', 'Rosca Direta (Halter)', 'Rosca Martelo', 'Rosca Scott', 'Rosca Concentrada', 'Rosca Polia']
  },
  arms_tri: {
    id: 'arms_tri',
    name: 'Tríceps',
    exercises: ['Tríceps Polia (Barra V)', 'Tríceps Corda', 'Tríceps Testa', 'Tríceps Francês', 'Mergulho (Paralelas/Banco)']
  },
  calves: {
    id: 'calves',
    name: 'Panturrilhas',
    exercises: ['Panturrilha em Pé (Máquina)', 'Panturrilha Sentado (Banco)', 'Panturrilha no Leg Press']
  },
  abs: {
    id: 'abs',
    name: 'Abdômen',
    exercises: ['Abdominal Supra', 'Abdominal Infra (Elevação de Pernas)', 'Prancha', 'Abdominal na Polia']
  }
};

export const WORKOUT_PLANS: Record<string, WorkoutPlan> = {
  ppl: {
    name: 'PPL (Push/Pull/Legs)',
    desc: 'Alta frequência, 3-6 dias por semana.',
    days: [
      { 
        id: 'push', 
        name: 'Empurrar (Peito/Ombro/Tríceps)', 
        exercises: [
          { name: 'Supino Reto (Barra)', category: 'compound_push_h' },
          { name: 'Supino Inclinado (Halter)', category: 'compound_push_h' },
          { name: 'Desenvolvimento Militar (Barra)', category: 'compound_push_v' },
          { name: 'Elevação Lateral (Halter)', category: 'iso_delt_side' },
          { name: 'Tríceps Polia (Barra V)', category: 'arms_tri' }
        ] 
      },
      { 
        id: 'pull', 
        name: 'Puxar (Costas/Bíceps)', 
        exercises: [
          { name: 'Levantamento Terra (Convencional)', category: 'legs_compound_post' },
          { name: 'Puxada Alta (Polia)', category: 'compound_pull_v' },
          { name: 'Remada Curvada (Barra)', category: 'compound_pull_h' },
          { name: 'Face Pull', category: 'iso_back' },
          { name: 'Rosca Direta (Barra)', category: 'arms_bi' },
          { name: 'Rosca Martelo', category: 'arms_bi' }
        ] 
      },
      { 
        id: 'legs', 
        name: 'Pernas (Completo)', 
        exercises: [
          { name: 'Agachamento Livre', category: 'legs_compound_quad' },
          { name: 'Leg Press 45', category: 'legs_compound_quad' },
          { name: 'Stiff (Barra/Halter)', category: 'legs_compound_post' },
          { name: 'Cadeira Extensora', category: 'legs_iso_quad' },
          { name: 'Mesa Flexora', category: 'legs_iso_post' },
          { name: 'Panturrilha em Pé (Máquina)', category: 'calves' }
        ] 
      }
    ]
  },
  upper_lower: {
    name: 'Upper / Lower',
    desc: 'Equilíbrio perfeito, 4 dias por semana.',
    days: [
      { 
        id: 'upper1', 
        name: 'Superiores A (Força)', 
        exercises: [
          { name: 'Supino Reto (Barra)', category: 'compound_push_h' },
          { name: 'Remada Curvada (Barra)', category: 'compound_pull_h' },
          { name: 'Desenvolvimento Militar (Barra)', category: 'compound_push_v' },
          { name: 'Barra Fixa (Pronada)', category: 'compound_pull_v' },
          { name: 'Tríceps Testa', category: 'arms_tri' },
          { name: 'Rosca Direta (Barra)', category: 'arms_bi' }
        ] 
      },
      { 
        id: 'lower1', 
        name: 'Inferiores A (Agachamento)', 
        exercises: [
          { name: 'Agachamento Livre', category: 'legs_compound_quad' },
          { name: 'Afundo/Passada', category: 'legs_compound_quad' },
          { name: 'Cadeira Extensora', category: 'legs_iso_quad' },
          { name: 'Mesa Flexora', category: 'legs_iso_post' },
          { name: 'Panturrilha em Pé (Máquina)', category: 'calves' }
        ] 
      },
      { 
        id: 'upper2', 
        name: 'Superiores B (Hipertrofia)', 
        exercises: [
          { name: 'Supino Inclinado (Halter)', category: 'compound_push_h' },
          { name: 'Puxada Alta (Polia)', category: 'compound_pull_v' },
          { name: 'Elevação Lateral (Halter)', category: 'iso_delt_side' },
          { name: 'Crucifixo (Máquina/Peck Deck)', category: 'iso_chest' },
          { name: 'Tríceps Corda', category: 'arms_tri' },
          { name: 'Rosca Scott', category: 'arms_bi' }
        ] 
      },
      { 
        id: 'lower2', 
        name: 'Inferiores B (Posterior)', 
        exercises: [
          { name: 'Levantamento Terra (Convencional)', category: 'legs_compound_post' },
          { name: 'Leg Press 45', category: 'legs_compound_quad' },
          { name: 'Mesa Flexora', category: 'legs_iso_post' },
          { name: 'Cadeira Extensora', category: 'legs_iso_quad' }, // Changed Adutora to Extensora for balance
          { name: 'Panturrilha Sentado (Banco)', category: 'calves' }
        ] 
      }
    ]
  },
  arnold: {
    name: 'Arnold Split',
    desc: 'Volume alto, 6 dias por semana.',
    days: [
      { 
        id: 'chest_back', 
        name: 'Peito e Costas', 
        exercises: [
          { name: 'Supino Reto (Barra)', category: 'compound_push_h' },
          { name: 'Barra Fixa (Pronada)', category: 'compound_pull_v' },
          { name: 'Supino Inclinado (Halter)', category: 'compound_push_h' },
          { name: 'Remada Curvada (Barra)', category: 'compound_pull_h' },
          { name: 'Crucifixo (Halter)', category: 'iso_chest' },
          { name: 'Pulldown (Polia)', category: 'iso_back' }
        ] 
      },
      { 
        id: 'delt_arm', 
        name: 'Ombros e Braços', 
        exercises: [
          { name: 'Desenvolvimento Militar (Barra)', category: 'compound_push_v' },
          { name: 'Elevação Lateral (Halter)', category: 'iso_delt_side' },
          { name: 'Rosca Direta (Barra)', category: 'arms_bi' },
          { name: 'Tríceps Testa', category: 'arms_tri' },
          { name: 'Rosca Concentrada', category: 'arms_bi' },
          { name: 'Tríceps Francês', category: 'arms_tri' }
        ] 
      },
      { 
        id: 'legs_abs', 
        name: 'Pernas e Abdômen', 
        exercises: [
          { name: 'Agachamento Livre', category: 'legs_compound_quad' },
          { name: 'Leg Press 45', category: 'legs_compound_quad' },
          { name: 'Stiff (Barra/Halter)', category: 'legs_compound_post' },
          { name: 'Cadeira Extensora', category: 'legs_iso_quad' },
          { name: 'Panturrilha em Pé (Máquina)', category: 'calves' },
          { name: 'Abdominal Infra (Elevação de Pernas)', category: 'abs' }
        ] 
      }
    ]
  }
};
