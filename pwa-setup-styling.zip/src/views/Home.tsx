import { WORKOUT_PLANS } from '../data';
import { ActiveWorkout } from '../types';
import { Play } from 'lucide-react';

interface HomeProps {
  onSelectPlan: (planKey: string) => void;
  lastWorkout?: ActiveWorkout;
  onRepeatWorkout: () => void;
}

export const Home = ({ onSelectPlan, lastWorkout, onRepeatWorkout }: HomeProps) => {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 space-y-4">
      <h2 className="text-2xl font-bold mb-4">Escolha sua Estratégia</h2>
      
      {Object.entries(WORKOUT_PLANS).map(([key, plan]) => (
        <div 
          key={key}
          onClick={() => onSelectPlan(key)} 
          className="bg-[#1f2937] rounded-xl p-4 mb-4 shadow-md active:scale-95 transition transform cursor-pointer border border-gray-700 hover:border-blue-500"
        >
          <h3 className="text-xl font-bold text-blue-400">{plan.name}</h3>
          <p className="text-gray-400 text-sm mt-1">{plan.desc}</p>
        </div>
      ))}
      
      {lastWorkout && (
        <div className="mt-8 pt-4 border-t border-gray-700">
          <h3 className="text-lg font-bold mb-2">Último Treino Realizado</h3>
          <div 
            onClick={onRepeatWorkout} 
            className="bg-blue-900/20 border border-blue-500/30 rounded-xl p-4 cursor-pointer hover:bg-blue-900/40 transition active:scale-95"
          >
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-bold text-blue-300">{lastWorkout.dayName}</h4>
                <p className="text-sm text-gray-400">Repetir: {new Date(lastWorkout.startTime).toLocaleDateString()}</p>
              </div>
              <Play className="w-6 h-6 text-blue-400" fill="currentColor" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
