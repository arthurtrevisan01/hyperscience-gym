import { Dumbbell, History, Database } from 'lucide-react';

interface NavigationProps {
  currentView: string;
  onNavigate: (view: string) => void;
}

export const Navigation = ({ currentView, onNavigate }: NavigationProps) => {
  const getButtonClass = (view: string) => {
    const isActive = currentView === view || (view === 'home' && currentView === 'workout_select');
    return `flex flex-col items-center transition ${isActive ? 'text-blue-400' : 'text-gray-400 hover:text-blue-400'}`;
  };

  return (
    <nav className="fixed bottom-0 w-full bg-gray-800 border-t border-gray-700 flex justify-around py-3 z-50 pb-[env(safe-area-inset-bottom)]">
      <button onClick={() => onNavigate('home')} className={getButtonClass('home')}>
        <Dumbbell className="w-6 h-6" />
        <span className="text-xs mt-1">Treinos</span>
      </button>
      <button onClick={() => onNavigate('history')} className={getButtonClass('history')}>
        <History className="w-6 h-6" />
        <span className="text-xs mt-1">Histórico</span>
      </button>
      <button onClick={() => onNavigate('settings')} className={getButtonClass('settings')}>
        <Database className="w-6 h-6" />
        <span className="text-xs mt-1">Dados</span>
      </button>
    </nav>
  );
};
