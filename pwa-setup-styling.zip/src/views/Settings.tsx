import { ActiveWorkout } from '../types';
import { Trash2, TrendingUp, Activity } from 'lucide-react';

interface SettingsProps {
  history: ActiveWorkout[];
  onReset: () => void;
}

export const Settings = ({ history, onReset }: SettingsProps) => {
  const totalWorkouts = history.length;
  const totalTons = history.reduce((acc, curr) => acc + (curr.analysis?.totalVolume || 0), 0) / 1000;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 pb-20">
      <h2 className="text-2xl font-bold mb-6">Estatísticas Gerais</h2>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-[#1f2937] rounded-xl p-6 text-center border border-gray-700">
          <Activity className="w-8 h-8 text-blue-500 mx-auto mb-2" />
          <p className="text-3xl font-bold text-white">{totalWorkouts}</p>
          <p className="text-gray-400 uppercase text-[10px] tracking-widest mt-1">Treinos</p>
        </div>

        <div className="bg-[#1f2937] rounded-xl p-6 text-center border border-gray-700">
          <TrendingUp className="w-8 h-8 text-purple-500 mx-auto mb-2" />
          <p className="text-3xl font-bold text-white">{totalTons.toFixed(1)}</p>
          <p className="text-gray-400 uppercase text-[10px] tracking-widest mt-1">Toneladas</p>
        </div>
      </div>

      <div className="mt-8 bg-red-900/20 p-4 rounded-xl border border-red-900/50">
        <h3 className="text-red-500 font-bold mb-2 flex items-center"><Trash2 className="w-5 h-5 mr-2" /> Zona de Perigo</h3>
        <button 
          onClick={() => {
            if(confirm('Tem certeza? Isso apagará todo seu histórico permanentemente.')){
              onReset();
            }
          }} 
          className="w-full bg-red-600 hover:bg-red-700 text-white py-3 rounded-lg font-bold transition"
        >
          RESETAR DADOS
        </button>
        <p className="text-xs text-red-400/70 text-center mt-2">Cuidado: Isso apaga seu histórico local.</p>
      </div>
      
      <div className="mt-8 text-center text-gray-600 text-xs">
        <p>HyperScience PWA v1.0</p>
        <p>Desenvolvido com React & Tailwind</p>
      </div>
    </div>
  );
};
