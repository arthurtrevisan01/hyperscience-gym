import { useState, useEffect } from 'react';
import { WORKOUT_PLANS } from '../data';
import { ExerciseDefinition } from '../types';
import { ArrowLeft, Play, RefreshCw, Settings2 } from 'lucide-react';
import { ExerciseSwapModal } from '../components/ExerciseSwapModal';

interface WorkoutSetupProps {
  planKey: string;
  dayIndex: number;
  onBack: () => void;
  onStart: (exercises: ExerciseDefinition[]) => void;
}

export const WorkoutSetup = ({ planKey, dayIndex, onBack, onStart }: WorkoutSetupProps) => {
  const plan = WORKOUT_PLANS[planKey];
  const day = plan.days[dayIndex];
  
  const [exercises, setExercises] = useState<ExerciseDefinition[]>([]);
  const [swappingIndex, setSwappingIndex] = useState<number | null>(null);

  useEffect(() => {
    // Deep copy initial exercises so we can modify them locally
    setExercises(day.exercises.map(ex => ({ ...ex })));
  }, [day]);

  const handleSwap = (newName: string) => {
    if (swappingIndex === null) return;
    
    const newExercises = [...exercises];
    newExercises[swappingIndex] = {
      ...newExercises[swappingIndex],
      name: newName
    };
    setExercises(newExercises);
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 pb-24">
      <div className="flex items-center justify-between mb-6">
        <button onClick={onBack} className="text-blue-400 text-sm flex items-center">
          <ArrowLeft className="w-4 h-4 mr-1" /> Voltar
        </button>
        <div className="text-gray-500 flex items-center text-xs">
          <Settings2 className="w-3 h-3 mr-1" /> Personalizar
        </div>
      </div>

      <h2 className="text-2xl font-bold mb-2">{day.name}</h2>
      <p className="mb-6 text-gray-400 text-sm">Toque nos exercícios para ver substituições <strong>biomecanicamente equivalentes</strong> e otimizadas para hipertrofia.</p>

      <div className="space-y-3 mb-8">
        {exercises.map((ex, index) => (
          <div 
            key={index}
            className="bg-[#1f2937] p-4 rounded-xl border border-gray-700 flex justify-between items-center group"
          >
            <div>
              <h4 className="font-bold text-white">{ex.name}</h4>
              <p className="text-xs text-gray-500 mt-1">Séries Recomendadas: 3-4</p>
            </div>
            
            {ex.category && (
              <button 
                onClick={() => setSwappingIndex(index)}
                className="p-2 bg-gray-800 hover:bg-blue-900/30 text-blue-400 rounded-lg transition"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
            )}
          </div>
        ))}
      </div>

      <button 
        onClick={() => onStart(exercises)}
        className="w-full bg-blue-600 hover:bg-blue-700 py-4 rounded-xl font-bold text-white shadow-lg text-lg flex items-center justify-center transition active:scale-95 fixed bottom-24 left-4 right-4 max-w-[calc(100%-2rem)] mx-auto z-40"
      >
        <Play className="w-5 h-5 mr-2" fill="currentColor" /> INICIAR TREINO
      </button>

      {swappingIndex !== null && exercises[swappingIndex] && (
        <ExerciseSwapModal
          isOpen={true}
          onClose={() => setSwappingIndex(null)}
          currentExerciseName={exercises[swappingIndex].name}
          categoryKey={exercises[swappingIndex].category}
          onSelect={handleSwap}
        />
      )}
    </div>
  );
};
