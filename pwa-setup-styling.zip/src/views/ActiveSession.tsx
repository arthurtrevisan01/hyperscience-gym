import { useState, useEffect } from 'react';
import { ActiveWorkout, WorkoutSet } from '../types';
import { X, Plus } from 'lucide-react';

interface ActiveSessionProps {
  workout: ActiveWorkout;
  onUpdateWorkout: (workout: ActiveWorkout) => void;
  onFinish: () => void;
}

export const ActiveSession = ({ workout, onUpdateWorkout, onFinish }: ActiveSessionProps) => {
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setElapsed(Math.floor((Date.now() - workout.startTime) / 1000));
    }, 1000);
    return () => clearInterval(interval);
  }, [workout.startTime]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const updateSet = (exIndex: number, setIndex: number, field: keyof WorkoutSet, value: string) => {
    const newWorkout = { ...workout };
    newWorkout.exercises[exIndex].sets[setIndex][field] = value;
    onUpdateWorkout(newWorkout);
  };

  const addSet = (exIndex: number) => {
    const newWorkout = { ...workout };
    const prevSet = newWorkout.exercises[exIndex].sets[newWorkout.exercises[exIndex].sets.length - 1];
    newWorkout.exercises[exIndex].sets.push({ ...prevSet });
    onUpdateWorkout(newWorkout);
  };

  const removeSet = (exIndex: number, setIndex: number) => {
    const newWorkout = { ...workout };
    if (newWorkout.exercises[exIndex].sets.length > 1) {
      newWorkout.exercises[exIndex].sets.splice(setIndex, 1);
      onUpdateWorkout(newWorkout);
    }
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 pb-24">
      <div className="flex justify-between items-end mb-4 sticky top-16 bg-gray-900 py-2 z-40 border-b border-gray-800">
        <div>
          <h2 className="text-xl font-bold text-white">{workout.dayName}</h2>
          <p className="text-xs text-blue-400 font-mono">{formatTime(elapsed)}</p>
        </div>
        <button 
          onClick={onFinish} 
          className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-lg transition"
        >
          FINALIZAR
        </button>
      </div>

      {workout.exercises.map((ex, exIndex) => (
        <div key={exIndex} className="bg-[#1f2937] rounded-xl p-4 mb-4 shadow-md border border-gray-700">
          <h3 className="font-bold text-lg mb-2 text-blue-300">{ex.name}</h3>
          
          <div className="grid grid-cols-4 gap-2 text-xs text-gray-500 mb-1 text-center font-bold">
            <span>KG</span>
            <span>REPS</span>
            <span>RPE (1-10)</span>
            <span></span>
          </div>

          <div className="space-y-2">
            {ex.sets.map((set, setIndex) => (
              <div key={setIndex} className="grid grid-cols-4 gap-2 items-center">
                <input 
                  type="number" 
                  placeholder="kg" 
                  value={set.weight} 
                  onChange={(e) => updateSet(exIndex, setIndex, 'weight', e.target.value)}
                  className="bg-gray-700 text-white border border-gray-600 rounded p-2 text-center w-full focus:border-blue-500 focus:outline-none"
                />
                <input 
                  type="number" 
                  placeholder="reps" 
                  value={set.reps} 
                  onChange={(e) => updateSet(exIndex, setIndex, 'reps', e.target.value)}
                  className="bg-gray-700 text-white border border-gray-600 rounded p-2 text-center w-full focus:border-blue-500 focus:outline-none"
                />
                <input 
                  type="number" 
                  placeholder="7-10" 
                  value={set.rpe} 
                  max="10"
                  onChange={(e) => updateSet(exIndex, setIndex, 'rpe', e.target.value)}
                  className={`bg-gray-700 text-white border rounded p-2 text-center w-full focus:outline-none ${parseInt(set.rpe) >= 9 ? 'text-red-400 border-red-900' : 'border-gray-600 focus:border-blue-500'}`}
                />
                <div className="flex justify-center">
                  <button 
                    onClick={() => removeSet(exIndex, setIndex)} 
                    className="text-red-500 hover:text-red-400 p-2"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>
            ))}
          </div>
          <button 
            onClick={() => addSet(exIndex)} 
            className="w-full mt-4 py-2 bg-gray-700 hover:bg-gray-600 rounded text-sm text-blue-300 font-bold flex items-center justify-center transition"
          >
            <Plus className="w-4 h-4 mr-1" /> Adicionar Série
          </button>
        </div>
      ))}
    </div>
  );
};
