import { EXERCISE_CATEGORIES } from '../data';
import { X, Check } from 'lucide-react';

interface ExerciseSwapModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentExerciseName: string;
  categoryKey: string;
  onSelect: (newName: string) => void;
}

export const ExerciseSwapModal = ({ isOpen, onClose, currentExerciseName, categoryKey, onSelect }: ExerciseSwapModalProps) => {
  if (!isOpen) return null;

  const category = EXERCISE_CATEGORIES[categoryKey];
  if (!category) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#1f2937] w-full max-w-md rounded-xl shadow-2xl border border-gray-700 max-h-[80vh] flex flex-col">
        <div className="p-4 border-b border-gray-700 flex justify-between items-center">
          <h3 className="text-lg font-bold text-white">Substituir Exercício</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-4 overflow-y-auto">
          <p className="text-sm text-gray-400 mb-4">
            Opções para <span className="text-blue-400 font-bold">{category.name}</span>:
          </p>
          
          <div className="space-y-2">
            {category.exercises.map((exName) => (
              <button
                key={exName}
                onClick={() => {
                  onSelect(exName);
                  onClose();
                }}
                className={`w-full text-left p-3 rounded-lg flex justify-between items-center transition ${
                  exName === currentExerciseName 
                    ? 'bg-blue-900/30 border border-blue-500/50 text-blue-300' 
                    : 'bg-gray-800 hover:bg-gray-700 text-gray-200 border border-transparent'
                }`}
              >
                <span>{exName}</span>
                {exName === currentExerciseName && <Check className="w-4 h-4" />}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
