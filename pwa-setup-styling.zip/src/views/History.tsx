import { ActiveWorkout } from '../types';
import { Calendar, Clock } from 'lucide-react';

interface HistoryProps {
  history: ActiveWorkout[];
}

export const History = ({ history }: HistoryProps) => {
  if (history.length === 0) {
    return (
      <div className="animate-in fade-in text-center mt-20 text-gray-500">
        <p className="text-xl mb-2">Nenhum treino realizado ainda.</p>
        <p>Vá puxar ferro!</p>
      </div>
    );
  }

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 space-y-4 pb-20">
      <h2 className="text-2xl font-bold mb-4">Seu Histórico</h2>
      
      {history.map((w, index) => (
        <div key={index} className="bg-[#1f2937] rounded-xl p-4 mb-4 shadow-md border border-gray-700">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-bold text-white text-lg">{w.dayName}</h3>
              <div className="flex items-center text-xs text-gray-400 mt-1 space-x-3">
                <span className="flex items-center"><Calendar className="w-3 h-3 mr-1" /> {new Date(w.startTime).toLocaleDateString()}</span>
                <span className="flex items-center"><Clock className="w-3 h-3 mr-1" /> {w.duration} min</span>
              </div>
            </div>
            <div className="text-right">
              {w.analysis && (
                <span className={`text-xl font-bold ${w.analysis.grade.includes('A') || w.analysis.grade.includes('S') ? 'text-green-400' : 'text-yellow-400'}`}>
                  {w.analysis.grade}
                </span>
              )}
            </div>
          </div>
          {w.analysis && (
            <p className="text-xs text-gray-500 mt-3 border-t border-gray-700 pt-2">
              Volume Total: <strong>{(w.analysis.totalVolume/1000).toFixed(1)} ton</strong>
            </p>
          )}
        </div>
      ))}
    </div>
  );
};
