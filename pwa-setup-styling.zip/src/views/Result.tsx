import { ActiveWorkout } from '../types';
import { Award, CheckCircle, BarChart2 } from 'lucide-react';

interface ResultProps {
  workout: ActiveWorkout;
  onHome: () => void;
}

export const Result = ({ workout, onHome }: ResultProps) => {
  const { analysis } = workout;
  if (!analysis) return null;

  const getGradeColor = (grade: string) => {
    if (grade.includes('S') || grade.includes('A')) return 'text-green-400';
    if (grade.includes('B')) return 'text-blue-400';
    if (grade.includes('C')) return 'text-yellow-400';
    return 'text-red-500';
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 pb-20 pt-4 text-center">
      <h2 className="text-3xl font-bold mb-2">Relatório Brutal</h2>
      <p className="text-gray-400 mb-6">Duração: {workout.duration} min</p>

      <div className="bg-[#1f2937] rounded-xl p-6 mb-6 border-2 border-gray-600 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <Award className="w-24 h-24" />
        </div>
        <p className="text-sm text-gray-400 uppercase tracking-widest mb-2">Sua Nota</p>
        <h1 className={`text-6xl font-black ${getGradeColor(analysis.grade)}`}>{analysis.grade}</h1>
      </div>

      <div className="text-left space-y-3 mb-8">
        {analysis.feedback.map((f, i) => (
          <div key={i} className="p-3 bg-[#1f2937] rounded border-l-4 border-blue-500 text-sm flex items-start">
            <span className="mr-2 mt-0.5">ℹ️</span>
            <p>{f}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-[#1f2937] rounded-xl p-4 shadow-md">
          <p className="text-xs text-gray-500 mb-1">Volume Total</p>
          <div className="flex items-center justify-center">
            <BarChart2 className="w-5 h-5 mr-2 text-purple-500" />
            <p className="text-xl font-bold text-white">
              {(analysis.totalVolume / 1000).toFixed(1)} <span className="text-sm text-gray-500">ton</span>
            </p>
          </div>
        </div>
        <div className="bg-[#1f2937] rounded-xl p-4 shadow-md">
          <p className="text-xs text-gray-500 mb-1">Séries Totais</p>
          <div className="flex items-center justify-center">
            <CheckCircle className="w-5 h-5 mr-2 text-green-500" />
            <p className="text-xl font-bold text-white">{analysis.totalSets}</p>
          </div>
        </div>
      </div>

      <button 
        onClick={onHome} 
        className="w-full bg-blue-600 hover:bg-blue-700 py-4 rounded-xl font-bold text-white shadow-lg text-lg transition transform active:scale-95"
      >
        VOLTAR AO INÍCIO
      </button>
    </div>
  );
};
