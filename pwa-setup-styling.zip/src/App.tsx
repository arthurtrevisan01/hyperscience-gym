import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { Home } from './views/Home';
import { WorkoutSelect } from './views/WorkoutSelect';
import { WorkoutSetup } from './views/WorkoutSetup';
import { ActiveSession } from './views/ActiveSession';
import { Result } from './views/Result';
import { History } from './views/History';
import { Settings } from './views/Settings';
import { WORKOUT_PLANS } from './data';
import { ActiveWorkout, ExerciseDefinition } from './types';
import { analyzeWorkout } from './utils/analysis';

export function App() {
  const [view, setView] = useState('home');
  const [history, setHistory] = useState<ActiveWorkout[]>(() => {
    const saved = localStorage.getItem('hyperHistory');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [activeWorkout, setActiveWorkout] = useState<ActiveWorkout | null>(null);
  const [selectedPlanKey, setSelectedPlanKey] = useState<string | null>(null);
  const [selectedDayIndex, setSelectedDayIndex] = useState<number | null>(null);

  useEffect(() => {
    localStorage.setItem('hyperHistory', JSON.stringify(history));
  }, [history]);

  const handleSelectPlan = (key: string) => {
    setSelectedPlanKey(key);
    setView('workout_select');
  };

  const handleSelectDay = (planKey: string, dayIndex: number) => {
    setSelectedPlanKey(planKey);
    setSelectedDayIndex(dayIndex);
    setView('workout_setup');
  };

  const handleStartWorkout = (exercises: ExerciseDefinition[]) => {
    if (!selectedPlanKey || selectedDayIndex === null) return;

    const plan = WORKOUT_PLANS[selectedPlanKey];
    const day = plan.days[selectedDayIndex];
    
    const newWorkout: ActiveWorkout = {
      planName: plan.name,
      dayName: day.name,
      exercises: exercises.map(ex => ({
        name: ex.name,
        category: ex.category,
        sets: [{ weight: '', reps: '', rpe: '' }]
      })),
      startTime: Date.now()
    };

    setActiveWorkout(newWorkout);
    setView('active_session');
  };

  const handleRepeatWorkout = (lastWorkout: ActiveWorkout) => {
    const newWorkout: ActiveWorkout = {
      planName: lastWorkout.planName,
      dayName: lastWorkout.dayName,
      exercises: lastWorkout.exercises.map(ex => ({
        name: ex.name,
        category: ex.category,
        sets: [{ weight: '', reps: '', rpe: '' }] // Reset sets for fresh workout
      })),
      startTime: Date.now()
    };
    setActiveWorkout(newWorkout);
    setView('active_session');
  };

  const handleFinishWorkout = () => {
    if (!activeWorkout) return;
    if (!confirm("Finalizar treino e gerar relatório?")) return;

    const endTime = Date.now();
    const duration = Math.floor((endTime - activeWorkout.startTime) / 1000 / 60);
    
    const finishedWorkout = {
      ...activeWorkout,
      endTime,
      duration
    };

    const analysis = analyzeWorkout(finishedWorkout);
    finishedWorkout.analysis = analysis;

    setHistory([finishedWorkout, ...history]);
    setActiveWorkout(finishedWorkout); // Keep it to show result
    setView('result');
  };

  const handleResetData = () => {
    setHistory([]);
    localStorage.removeItem('hyperHistory');
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans antialiased pb-20 select-none">
      <Header />

      <main className="mt-20 px-4 container mx-auto">
        {view === 'home' && (
          <Home 
            onSelectPlan={handleSelectPlan} 
            lastWorkout={history[0]} 
            onRepeatWorkout={() => handleRepeatWorkout(history[0])}
          />
        )}
        
        {view === 'workout_select' && selectedPlanKey && (
          <WorkoutSelect 
            planKey={selectedPlanKey} 
            onBack={() => setView('home')} 
            onSelectDay={handleSelectDay} 
          />
        )}

        {view === 'workout_setup' && selectedPlanKey && selectedDayIndex !== null && (
          <WorkoutSetup
            planKey={selectedPlanKey}
            dayIndex={selectedDayIndex}
            onBack={() => setView('workout_select')}
            onStart={handleStartWorkout}
          />
        )}

        {view === 'active_session' && activeWorkout && (
          <ActiveSession 
            workout={activeWorkout} 
            onUpdateWorkout={setActiveWorkout}
            onFinish={handleFinishWorkout}
          />
        )}

        {view === 'result' && activeWorkout && (
          <Result 
            workout={activeWorkout} 
            onHome={() => {
              setActiveWorkout(null);
              setView('home');
            }} 
          />
        )}

        {view === 'history' && (
          <History history={history} />
        )}

        {view === 'settings' && (
          <Settings history={history} onReset={handleResetData} />
        )}
      </main>

      {view !== 'active_session' && view !== 'result' && view !== 'workout_setup' && (
        <Navigation currentView={view} onNavigate={setView} />
      )}
    </div>
  );
}
